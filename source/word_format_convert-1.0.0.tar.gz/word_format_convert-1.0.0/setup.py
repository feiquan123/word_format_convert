# encoding=utf-8

from distutils.core import setup,Extension

setup(
    name="word_format_convert",
    version="1.0.0",
    description="统一的文本数据清洗",
    long_description="统一的文本数据清洗",
    author="feiquan123",
    author_email="feiquanxx@gmail.com",
    download_url="https://github.com/feiquan123/word_format_convert.git",
    keywords="text data clear"
)